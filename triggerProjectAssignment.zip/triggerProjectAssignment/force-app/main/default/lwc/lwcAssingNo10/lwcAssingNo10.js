import { LightningElement, api, track } from 'lwc';
import upConToggle from '@salesforce/apex/lwcNo10upToggle.upConToggle';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class LwcAssingNo10 extends LightningElement {
    @api recordId;
    @track isChecked = false;
    @track error;
    @track firstName = '';
    @track lastName;

    handleCheckboxChange(event) {
        this.isChecked = event.target.checked;
    }

    handleLastNameChange(event) {
        this.lastName = event.target.value;
    }

    handleFirstNameChange(event) {
        this.firstName = event.target.value;
    }

    handleSave(){

        upConToggle({
            contactId: this.recordId,
            isChecked: this.isChecked,
            firstName: this.firstName,
        })
        .then(() => {
            this.ShowToastEvent('Success', 'Toggle updated successfully.', 'success');
        })
        .catch(error => {
            this.ShowToastEvent('Error', error.body.message, 'error');
        });
    }

    handleCancel(){
          this.firstName = '',
          this.lastName = '',
          this.isChecked = false,
          this.recordId = ''       
    }

    ShowToastEvent(title, message, variant) {
        const evt = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
        });
        this.dispatchEvent(evt);
    }

}