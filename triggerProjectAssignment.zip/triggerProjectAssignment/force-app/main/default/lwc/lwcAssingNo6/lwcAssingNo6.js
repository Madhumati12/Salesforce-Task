import { LightningElement, track, wire } from 'lwc';
import upLeadRec from '@salesforce/apex/lwcNo6UpdateLead.upLeadRec';
import { loadStyle } from 'lightning/platformResourceLoader';
import CUSTOM_STYLES from '@salesforce/resourceUrl/LwcColor';

export default class LwcAssingNo6 extends LightningElement {
    @track leadData;
    @track error;

    connectedCallback() {
        loadStyle(this, CUSTOM_STYLES);
    }

    @wire(upLeadRec)
    leadRecord({error, data}){

        if(data){
            this.leadData = data.map((lead, index) => {
                return {
                    serialNumber: index + 1,
                    StageClass: this.getStageClass(lead.Stage__c),
                    ...lead
                };
            });
            this.error = undefined;
        } else if(error){
            this.error = error;
            this.leadData = undefined;
        }
    }

    getStageClass(stage) {
       console.log(`Determining stage class for stage: ${stage}`);
        switch (stage) {
          case 'Active':
            return 'slds-text-color_success';
          case 'New':
            return 'slds-text-color_custom-warning';
          case 'Junk':
            return 'slds-text-color_error';
          default:
            return '';
        }
      }
    }