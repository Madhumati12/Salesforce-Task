import { LightningElement, api } from 'lwc';

export default class LwcSh3FormContainerChild extends LightningElement {
    @api label;
    @api value = '';
    @api isRequired = false;

    handleInputChange(event) {
        const inputValue = event.detail.value;
        const inputChangeEvent = new CustomEvent('inputchange', {
            detail: { label: this.label, value: inputValue }
        });
        this.dispatchEvent(inputChangeEvent);
    }
}