import { LightningElement, track } from 'lwc';

export default class LwcSh3ProductListParent extends LightningElement {
    @track product = [
        {id : 1, Name : 'Product 1', Price : '100', Description : 'This is Product 1'},
        {id : 2, Name : 'Product 2', Price : '200', Description : 'This is Product 2'},
        {id : 3, Name : 'Product 3', Price : '300', Description : 'This is Product 3'},
    ];
    @track selectedProduct = null;

    handleProductSelect(event){
        const ProductId = event.detail.ProductId;
        this.selectedProduct = this.product.find(product => product.id == ProductId);
        console.log(this.selectedProduct);
        console.log(this.selectedProduct.Name);  
    }
}