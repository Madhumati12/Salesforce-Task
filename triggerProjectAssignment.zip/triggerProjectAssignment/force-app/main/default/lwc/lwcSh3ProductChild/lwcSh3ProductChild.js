import { LightningElement , api} from 'lwc';

export default class LwcSh3ProductChild extends LightningElement {
    @api product;

    handleSelect(){

        const selectEvent = new CustomEvent('select', {
            detail: { ProductId : this.product.id }
        });
        this.dispatchEvent(selectEvent);
    }
}