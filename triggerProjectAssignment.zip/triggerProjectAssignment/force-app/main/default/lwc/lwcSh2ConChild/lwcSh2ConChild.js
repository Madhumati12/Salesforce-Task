import { LightningElement } from 'lwc';

export default class LwcSh2ConChild extends LightningElement {}