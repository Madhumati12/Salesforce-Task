import { LightningElement, api, track } from 'lwc';
// import { loadScript } from 'lightning/platformResourceLoader';
// import CHART_JS from '@salesforce/resourceUrl/chartjs'; // Update this name to match your static resource name

export default class SalesPerformanceChart extends LightningElement {
  //  @api chartData = [
        // { Sales_Date__c: '2024-01-01', Sales_Amount__c: 5000 },
        // { Sales_Date__c: '2024-02-01', Sales_Amount__c: 3000 },
        // { Sales_Date__c: '2024-03-01', Sales_Amount__c: 7000 },
        // { Sales_Date__c: '2024-04-01', Sales_Amount__c: 4000 },
        // { Sales_Date__c: '2024-05-01', Sales_Amount__c: 8000 },
        // { Sales_Date__c: '2024-06-01', Sales_Amount__c: 6000 },
        // { Sales_Date__c: '2024-07-01', Sales_Amount__c: 9000 }
    // ];
    // @api salesPerformanceData;
    // @track processedData = [];
    // chartJs;
    // chart;
    // @api records;
    // @track page = 1;
    // @track pageSize = 10;
    // @track totalPages = 1;

    // get columns() {
    //     return [
    //         { label: 'ID', fieldName: 'Id' },
    //         { label: 'Name', fieldName: 'Name' },
    //         { label: 'Date Range', fieldName: 'Date_Range__c' },
    //         { label: 'Product Category', fieldName: 'Product_Category__c' },
    //         { label: 'Region', fieldName: 'Region__c' }
    //     ];
    // }

    // get paginatedRecords() {
    //     if (!this.records) return [];

    //     const start = (this.page - 1) * this.pageSize;
    //     const end = start + this.pageSize;
    //     this.totalPages = Math.ceil(this.records.length / this.pageSize);
    //     return this.records.slice(start, end);
    // }

    // handleNextPage() {
    //     if (this.page < this.totalPages) {
    //         this.page += 1;
    //     }
    // }

    // handlePrevPage() {
    //     if (this.page > 1) {
    //         this.page -= 1;
    //     }
    // }

    // get isFirstPage() {
    //     return this.page === 1;
    // }

    // get isLastPage() {
    //     return this.page === this.totalPages;
    // }
  

    // renderedCallback() {
    //     if (this.chartJs) {
    //         this.renderChart();
    //         return;
    //     }
    //     this.loadChartJs();
    // }

    // loadChartJs() {
    //     loadScript(this, CHART_JS)
    //         .then(() => {
    //             this.chartJs = window.Chart;
    //             this.renderChart();
    //         })
    //         .catch(error => {
    //             console.error("Error loading Chart.js library", error);
    //         });
    // }


    // renderChart() {
    //     if (this.chart) {
    //         this.chart.destroy();
    //     }

    //     this.processedData = this.chartData.map(record => ({
    //         x: record.Sales_Date__c,
    //         y: record.Sales_Amount__c
    //     }));

    // renderChart() {
    //     this.processedData = this.chartData.map(record => ({
    //         x: record.Sales_Date__c,
    //         y: record.Sales_Amount__c
    //     }));

        // const ctx = this.template.querySelector('canvas.chart').getContext('2d');
        // new this.chartJs(ctx, {
        //     type: 'bar',
        //     data: {
        //         labels: this.processedData.map(record => record.x),
        //         datasets: [{
        //             label: 'Sales Amount',
        //             data: this.processedData.map(record => record.y)
        //         }]
        //     },

    //     const labels = ['Date Range', 'Product Category', 'Region'];
    //     const ctx = this.template.querySelector('canvas.chart').getContext('2d');
    //     this.chart = new this.chartJs(ctx, {
    //         type: 'bar',
    //      data : {
    //         labels: labels,
    //         datasets: [{
    //             label: 'Sales Dataset',
    //             data: [65, 59, 80, 81, 56, 55, 40],
    //             backgroundColor: [
    //                 'rgba(255, 99, 132, 0.2)',
    //                 'rgba(255, 159, 64, 0.2)',
    //                 'rgba(255, 205, 86, 0.2)'
                    
    //             ],
    //             borderColor: [
    //                 'rgb(255, 99, 132)',
    //                 'rgb(255, 159, 64)',
    //                 'rgb(255, 205, 86)'
                   
    //             ],
    //             borderWidth: 1
    //         }]
    //     },

    
    //     options: {
    //         scales: {
    //             x: {
    //                 beginAtZero: true
    //             },
    //             y: {
    //                 beginAtZero: true
    //             }
    //         }
    //     }
    // });
}




         // Pie Chart Data
        //  const pieData = {
        //     labels: ['Positive', 'Neutral', 'Negative'],
        //     datasets: [{
        //         label: 'Customer Feedback',
        //         data: [60, 25, 15], // Example data
        //         backgroundColor: [
        //             'rgba(75, 192, 192, 0.2)',
        //             'rgba(255, 159, 64, 0.2)',
        //             'rgba(255, 99, 132, 0.2)'
        //         ],
        //         borderColor: [
        //             'rgb(75, 192, 192)',
        //             'rgb(255, 159, 64)',
        //             'rgb(255, 99, 132)'
        //         ],
        //         borderWidth: 1
        //     }]
        // };

        // // Pie Chart Rendering
        // const pieCtx = this.template.querySelector('canvas.pie-chart').getContext('2d');
        // this.pieChart = new this.chartJs(pieCtx, {
        //     type: 'pie',
        //     data: pieData,
        //     options: {
        //         responsive: true,
        //         plugins: {
        //             legend: {
        //                 position: 'top',
        //             },
        //             tooltip: {
        //                 callbacks: {
        //                     label: function(context) {
        //                         let label = context.label || '';
        //                         if (context.parsed !== null) {
        //                             label += ': ' + context.parsed + '%';
        //                         }
        //                         return label;
        //                     }
        //                 }
        //             }
        //         }
        //     }
        // });



    

            // const ctx = this.template.querySelector('canvas.chart').getContext('2d');
            // this.chart = new this.chartJs(ctx, {
            //     type: 'bar',
            //     data: {
            //         labels: this.processedData.map(record => record.x),
            //         datasets: [{
            //             label: 'Sales Amount',
            //             data: [65, 59, 80, 81, 56, 55, 40],
            //             backgroundColor: [
            //             'rgba(255, 99, 132, 0.2)',
            //             'rgba(255, 159, 64, 0.2)',
            //             'rgba(255, 205, 86, 0.2)',
            //             'rgba(75, 192, 192, 0.2)',
            //             'rgba(54, 162, 235, 0.2)',
            //             'rgba(153, 102, 255, 0.2)',
            //             'rgba(201, 203, 207, 0.2)'
            //             ],
            //             borderColor: [
            //             'rgb(255, 99, 132)',
            //             'rgb(255, 159, 64)',
            //             'rgb(255, 205, 86)',
            //             'rgb(75, 192, 192)',
            //             'rgb(54, 162, 235)',
            //             'rgb(153, 102, 255)',
            //             'rgb(201, 203, 207)'
            //             ],
            //             borderWidth: 1

                        // data: this.processedData.map(record => record.y),
                        // backgroundColor: 'rgba(75, 192, 192, 0.2)',
                        // borderColor: 'rgba(75, 192, 192, 1)',
                        // borderWidth: 1
                //     }]
                // },

//             options: {
//                 scales: {
//                     x: {
//                         type: 'category',
//                         labels: this.processedData.map(record => record.x)
//                     },
//                     y: {
//                         beginAtZero: true
//                     }
//                 }
//             }
//         });
//     }
// }
