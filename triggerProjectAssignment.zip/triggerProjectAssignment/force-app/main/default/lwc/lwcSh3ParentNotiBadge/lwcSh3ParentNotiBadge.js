import { LightningElement, track } from 'lwc';

export default class LwcSh3ParentNotiBadge extends LightningElement {
    @track notifications = [
        { id: '1', message: 'New message from John' },
        { id: '2', message: 'Reminder: Team meeting at 3 PM' },
    ];
    
    @track unreadCount = this.notifications.length;

    handleNotificationRead(event) {
        this.unreadCount -= 1;
        const message = event.detail.message;
        this.notifications = this.notifications.filter(notification => notification.message !== message);
    }
}