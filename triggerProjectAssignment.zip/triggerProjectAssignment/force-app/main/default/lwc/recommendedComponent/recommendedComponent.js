import { LightningElement } from 'lwc';

export default class RecommendedComponent extends LightningElement {}