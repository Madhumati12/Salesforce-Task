import { LightningElement, api, track } from 'lwc';
//import creConRecAcc from '@salesforce/apex/lwcNo2CreRecAcc.creConRecAcc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { createRecord } from 'lightning/uiRecordApi';
import CONTACT_OBJECT from '@salesforce/schema/Contact';
import FIRST_NAME_FIELD from '@salesforce/schema/Contact.FirstName';
import LAST_NAME_FIELD from '@salesforce/schema/Contact.LastName';
import EMAIL_FIELD from '@salesforce/schema/Contact.Email';
import PHONE_FIELD from '@salesforce/schema/Contact.Phone';
import ACCOUNT_FIELD from '@salesforce/schema/Contact.AccountId';


export default class LwcAssing02 extends LightningElement {
@track firstName = '';
@track lastName = ''; 
@track email = '';
@track phone = '';

@api recordId;

handleInputChange(event){

    const field = event.target.name;
    if(field === 'firstName'){
        this.firstName = event.target.value;
    }
    else if(field === 'lastName'){
        this.lastName = event.target.value;
    }
    else if(field === 'email'){
        this.email = event.target.value;
    }
    else if(field === 'phone'){
        this.phone = event.target.value;
    }
}   

newContact() {
    const fields = {};
    
    fields[FIRST_NAME_FIELD.fieldApiName] = this.firstName;
    fields[LAST_NAME_FIELD.fieldApiName] = this.lastName;
    fields[EMAIL_FIELD.fieldApiName] = this.email;
    fields[PHONE_FIELD.fieldApiName] = this.phone;
    fields[ACCOUNT_FIELD.fieldApiName] = this.recordId;

    const recordInput = { apiName: CONTACT_OBJECT.objectApiName, fields };

    createRecord( recordInput )
        .then(Contact => {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Success',
                    message: 'Contact Created',
                    variant: 'success'
                }),
            );
            this.handleReset();
        })
        .catch(error => {
            console.error("Error updating record:", error);
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error updating record',
                    message: error.body.message,
                    variant: 'error'
                }),
            );
        });
}
handleReset() {
   // this.error = undefined;
    this.firstName = '';
    this.lastName = '';
    this.email = '';
    this.phone = '';
   // this.resetFormElements(event.target);
}
}