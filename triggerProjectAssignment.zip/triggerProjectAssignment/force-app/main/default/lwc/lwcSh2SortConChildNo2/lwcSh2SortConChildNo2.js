import { LightningElement, api } from 'lwc';

export default class LwcSh2SortConChildNo2 extends LightningElement {
    @api sortedBy; 
    @api sortDirection = 'asc'; 

    handleSort(event) {
        const fieldName = event.target.dataset.field;
        const sortDirection = this.getNextDirection(fieldName);

        this.dispatchEvent(new CustomEvent('sort', {
            detail: { fieldName, sortDirection }
        }));
    }

    getNextDirection(fieldName) {
        return this.sortedBy === fieldName ? 
            (this.sortDirection === 'asc' ? 'desc' : 'asc') : 'asc';
    }
}