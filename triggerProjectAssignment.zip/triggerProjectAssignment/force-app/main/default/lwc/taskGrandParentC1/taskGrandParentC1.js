import { LightningElement ,track} from 'lwc';

export default class TaskGrandParentC1 extends LightningElement {
    @track selectedContacts = [];

    handleAddContacts(event) {
        this.selectedContacts = event.detail;
    }
    handleProductSelect(event){
        const ProductId = event.detail.ProductId;
        this.selectedProduct = this.product.find(product => product.id == ProductId);
        console.log(this.selectedProduct);
        console.log(this.selectedProduct.Name);  
    }
}