import { LightningElement, api } from 'lwc';

export default class LwcSh3ChildNoti extends LightningElement {
    @api message;  // Notification message

    handleMarkAsRead() {
        const readEvent = new CustomEvent('notificationread', {
            detail: { message: this.message }
        });
        this.dispatchEvent(readEvent);
    }
}