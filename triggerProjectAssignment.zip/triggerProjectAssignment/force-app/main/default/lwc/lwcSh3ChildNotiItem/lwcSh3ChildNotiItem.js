import { LightningElement ,api} from 'lwc';

export default class LwcSh3ChildNotiItem extends LightningElement {
    @api message;
    @api notificationId; 

    handleDismiss() {
        const dismissEvent = new CustomEvent('dismiss', {
            detail: {
                notificationId: this.notificationId 
            }
        });
        this.dispatchEvent(dismissEvent); 
    }
}