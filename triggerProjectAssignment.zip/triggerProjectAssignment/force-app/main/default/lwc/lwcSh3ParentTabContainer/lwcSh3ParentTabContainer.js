import { LightningElement, track } from 'lwc';

export default class LwcSh3ParentTabContainer extends LightningElement {
    @track activeTab = 'tab1';

    tabs = [
        { id: 'tab1', label: 'Tab 1' },
        { id: 'tab2', label: 'Tab 2' },
        { id: 'tab3', label: 'Tab 3' }
    ];

    handleTabClick(event) {
        const tabId = event.target.dataset.id;
        this.activeTab = tabId;
    }

    get tabContent() {
        return this.tabs.map(tab => {
            return {
                ...tab,
                isActive: this.activeTab === tab.id
            };
        });
    }

    tabClass(tabId) {
        return this.activeTab === tabId ? 'slds-button slds-button_neutral slds-is-active' : 'slds-button slds-button_neutral';
    }
}