import { LightningElement, api,track, wire } from 'lwc';
import upConStaff from '@salesforce/apex/lwcNo9UpConStaff.upConStaff';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getStaffTypes from '@salesforce/apex/lwcNo9UpConStaff.getStaffTypes';
 

export default class LwcStaffType extends LightningElement {
     @api recordId;
     @track options = [];
     @track selectedValues = [];
     @track error;

    @wire(getStaffTypes)
    wiredStaffTypes({ error, data }) {
        if (data) {
            this.options = data.map(option => ({ label: option, value: option }));
        } else if (error) {
            this.error = error;
        }
    }

    handleSelectionChange(event) {
        this.selectedValues = event.detail.value;
    }

    handleSave() {
        upConStaff({ contactId: this.recordId, staff: this.selectedValues.join(';') })
            .then(() => {
                this.showToast('Success', 'Staff Types updated successfully.', 'success');
            })
            .catch(error => {
                this.showToast('Error', error.body.message, 'error');
            });
    }

    showToast(title, message, variant) {
        const evt = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
        });
        this.dispatchEvent(evt);
    }
 }