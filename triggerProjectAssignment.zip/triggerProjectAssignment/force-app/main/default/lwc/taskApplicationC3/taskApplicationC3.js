import { LightningElement, track, wire } from 'lwc';
import { subscribe, MessageContext } from 'lightning/messageService';
import APPLICATION_CHANNEL from '@salesforce/messageChannel/JobSelectedChannel__c';
import getApplicants from '@salesforce/apex/LoginController.getApplicants';
import { refreshApex } from '@salesforce/apex';

export default class TaskApplicationC3 extends LightningElement {
    @track contacts = [];
    @track jobDetails;
    @track jobId;  // No need to use 'this' in @wire
    @track isLoading = false;
    @track currentPage = 1;  // Track the current page
    @track pageSize = 5;      // Number of records per page
    @track totalRecords = 0;  // Total number of records
    @track totalPages = 0; 
    @track isModalOpen = false;
    @track selectedRecordId;
    subscription = null;
    wiredContactsInfo;
    @track applicants = [];  // Track applicants list to ensure reactivity

    applicantColumns = [
        { label: 'Name', fieldName: 'Name' },
        { label: 'Phone', fieldName: 'Phone__c' },
        { label: 'Job', fieldName: 'Job__c' },
        {
            type: 'action',
            typeAttributes: {
                rowActions: [
                    { label: 'Edit', name: 'edit', iconName: 'utility:edit', title: 'Edit' }
                ],
                menuAlignment: 'right'
            }
        }
    ];

    @wire(getApplicants, { jobId: '$jobId' }) // Correct reference to jobId
    wiredData(result) {
        this.wiredContactsInfo = result;
        if (result.data) {
            console.log('Applicants:', JSON.stringify(result.data));
            this.applicants = result.data;
        } else if (result.error) {
            console.error('Error fetching applicants:', result.error);
        } else {
            console.log('No Applicants Found.');
        }
    }

    @wire(MessageContext)
    messageContext;

    connectedCallback() {
        this.subscription = subscribe(
            this.messageContext,
            APPLICATION_CHANNEL,
            (message) => this.handleMessage(message)
        );
    }

    handleMessage(message) {
        this.jobDetails = message.selectedJob;
        this.jobId = this.jobDetails.Id;
        console.log('Job Details:', JSON.stringify(this.jobDetails));
        console.log('Job ID:', this.jobId);

        // Explicitly trigger refresh if jobId is set
        if (this.jobId) {
            refreshApex(this.wiredContactsInfo);
        }
    }

    loadContacts() {
        this.isLoading = true;
        getMatchingContactsAndJobs({
            jobId: this.jobId,
            pageSize: this.pageSize,
            pageNumber: this.currentPage
        })
        .then(result => {
            this.contacts = result.contacts;
            this.totalRecords = result.totalRecords;
            this.totalPages = Math.ceil(this.totalRecords / this.pageSize);
            this.isLoading = false;
        })
        .catch(error => {
            console.error('Error loading contacts:', error);
            this.isLoading = false;
        });
    }

    handlePreviousPage() {
        if (this.currentPage > 1) {
            this.currentPage--;
            this.loadContacts();
        }
    }

    handleNextPage() {
        if (this.currentPage < this.totalPages) {
            this.currentPage++;
            this.loadContacts();
        }
    }

    handleRowAction(event) {
        const actionName = event.detail.action.name;
        const row = event.detail.row;
    
        switch (actionName) {
            case 'edit':
                this.openModal(row.Id); // Pass the selected record Id
                break;
            default:
                break;
        }
    }

    openModal(recordId) {
        this.selectedRecordId = recordId;
        this.isModalOpen = true;
    }

    closeModal() {
        this.isModalOpen = false;
        this.selectedRecordId = null; // Clear the selected record ID

    }

    handleSuccess() {
        this.closeModal();
        this.refreshData(); // Refresh the data to reflect changes
    }


    refreshData() {
        refreshApex(this.wiredContactsInfo);
    }
}
