import { LightningElement , api} from 'lwc';

export default class LwcSh3ChildTabCon extends LightningElement {
    @api tabId;

    get isActive(){
        return true;
    }
}