import { LightningElement , api} from 'lwc';
import createCon from '@salesforce/apex/createLwcDemoConLogin.createCon';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class LwcDemoDesignAttribute extends LightningElement {
    @api title;
    @api showPasswordField;

    
    firstName = '';
    lastName = '';
    email = '';
    password = '';

    handleInputChange(event) {
        const field = event.target.id;
        this[field] = event.target.value;
    }

    handleRegister() {
        // Call Apex method to create the contact
        createCon({ firstName: this.firstName, lastName: this.lastName, email: this.email, password: this.password })
            .then(result => {
                // Show success message
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: result,
                        variant: 'success',
                    })
                );

                // Clear the form after successful contact creation
                this.handleCancel();
            })
            .catch(error => {
                // Show error message
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error',
                        message: error.body.message,
                        variant: 'error',
                    })
                );
            });
    }

    handleCancel() {
        this.firstName = '';
        this.lastName = '';
        this.email = '';
        this.password = '';

        // Reset the input fields in the DOM to clear the values
        this.template.querySelectorAll('input').forEach(input => {
            input.value = '';
        });
    }
}