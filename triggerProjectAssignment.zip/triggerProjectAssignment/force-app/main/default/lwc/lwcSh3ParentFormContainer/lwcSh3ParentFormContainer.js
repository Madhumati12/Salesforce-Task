import { LightningElement, track } from 'lwc';

export default class LwcSh3ParentFormContainer extends LightningElement {
    @track firstName = '';
    @track lastName = '';
    @track email = '';
    @track isDisableChange = true;

    handleInputChange(event) {
        const { label, value } = event.detail;

        if (label === 'FirstName') {
            this.firstName = value;
        } else if (label === 'LastName') {
            this.lastName = value;
        } else if (label === 'Email') {
            this.email = value;
        }

        this.validForm();
    }

    validForm() {
        this.isDisableChange = !(this.firstName && this.lastName && this.email);
    }

    handleSubmit() {
        const submitEvent = new CustomEvent('submit', {
            detail: { 
                firstName: this.firstName, 
                lastName: this.lastName, 
                email: this.email 
            }
        });
        this.dispatchEvent(submitEvent);
    }
}