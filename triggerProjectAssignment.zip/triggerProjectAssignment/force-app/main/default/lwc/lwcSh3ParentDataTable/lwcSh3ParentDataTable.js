import { LightningElement, track } from 'lwc';

export default class LwcSh3ParentDataTable extends LightningElement {
    @track records = [
        { id: 1, name: 'Record 1', createdDate: '2024-08-22', status: 'open' },
        { id: 2, name: 'Record 2', createdDate: '2024-08-22', status: 'closed' },
        { id: 3, name: 'Record 3', createdDate: '2024-08-23', status: 'open' }
    ];

    @track filteredRecords = [...this.records];

    columns = [
        { label: 'Name', fieldName: 'name' },
        { label: 'Created Date', fieldName: 'createdDate' },
        { label: 'Status', fieldName: 'status' }
    ];

    handleFilterChange(event) {
        const { createdDate, status } = event.detail;
        this.applyFilters(createdDate, status);
    }

    applyFilters(createdDate, status) {
        this.filteredRecords = this.records.filter(record => {
            let dateMatch = true;
            let statusMatch = true;

            if (createdDate) {
                dateMatch = record.createdDate === createdDate;
            }

            if (status) {
                statusMatch = record.status === status;
            }

            return dateMatch && statusMatch;
        });
    }
}