import { LightningElement, track, api } from 'lwc';
import { updateRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';


export default class LwcAssingNo4 extends LightningElement {
@api recordId;
@track subject;
@track description;
@track status;

@track statusOption =[
    {label:'New', value:'New'},
    {label:'Working', value:'Working'},
    {label:'Escalated', value:'Escalated'},
    {label:'Closed', value:'Closed'}
];

handleSubjectChange(event){
    this.status = event.detail.value;
}
handleDescriptionChange(event){
    this.description = event.target.value;
}
handleSubjectChange(event){
    this.subject = event.target.value;
}
updateRecordHandler(){
    const fields = {'Id':this.recordId, 'Subject':this.subject,'Status':this.status, 'Description':this.description};
const recordInput = {fields};

updateRecord(recordInput)
.then(() =>{
    this.dispatchEvent(
        new ShowToastEvent({
            title : 'Success',
            message: 'Record Updated Sucessfully',
            variant: 'Success'
        })
    );
})
.catch(error => {
    this.dispatchEvent(
        new ShowToastEvent({
            title: 'Error',
            message: 'error.body.message',
            variant: 'Error'
        })
    );
})
}

}