import { LightningElement, wire, track } from 'lwc';
import getJobs from '@salesforce/apex/LoginController.getJobs';

export default class TaskRecruitingDashboard extends LightningElement {
    @track jobs = [];
    @track filteredJobs = [];

    @track skillOptions = [
        { label: 'C', value: 'C' },
        { label: 'Java', value: 'Java' },
        { label: 'Apex', value: 'Apex' },
        { label: 'Python', value: 'Python' },
        { label: 'C++', value: 'C++' }
    ];

    @track statusOptions = [
        { label: 'Open', value: 'Open' },
        { label: 'Closed', value: 'Closed' },
        { label: 'In Progress', value: 'In Progress' }
    ];

    selectedSkills = [];
    selectedStatus = '';
    selectedClient = '';
    selectedCity = '';
    activeOnly = false;

    @wire(getJobs)
    wiredJobs({ data, error }) {
        if (data) {
            this.jobs = data;
            this.filteredJobs = data; // Initialize filteredJobs with all jobs
        } else if (error) {
            console.error(error);
        }
    }

    handleTemporaryClick() {
        this.filteredJobs = this.jobs.filter(job => job.Type__c === 'Temporary');
        this.applyFilters();
    }

    handlePermanentClick() {
        this.filteredJobs = this.jobs.filter(job => job.Type__c === 'Permanent');
        this.applyFilters();
    }

    handleSkillChange(event) {
        this.selectedSkills = event.detail.value;
        this.applyFilters();
    }

    handleStatusChange(event) {
        this.selectedStatus = event.detail.value;
        this.applyFilters();
    }

    handleClientChange(event) {
        this.selectedClient = event.target.value;
        this.applyFilters();
    }

    handleCityChange(event) {
        this.selectedCity = event.target.value;
        this.applyFilters();
    }

    handleActiveChange(event) {
        this.activeOnly = event.target.checked;
        this.applyFilters();
    }

    applyFilters() {
        this.filteredJobs = this.jobs.filter(job => {
            // Ensure Skills__c is an array or can be compared with selectedSkills
            const skills = job.Skills__c ? job.Skills__c.split(';') : [];
            let skillMatch = this.selectedSkills.length === 0 || this.selectedSkills.some(skill => skills.includes(skill));
            let statusMatch = !this.selectedStatus || job.Status__c === this.selectedStatus;
            let clientMatch = !this.selectedClient || job.Client__c.toLowerCase().includes(this.selectedClient.toLowerCase());
            let cityMatch = !this.selectedCity || job.City__c.toLowerCase().includes(this.selectedCity.toLowerCase());
            let activeMatch = !this.activeOnly || job.Active__c;

            return skillMatch && statusMatch && clientMatch && cityMatch && activeMatch;
        });
    }
}