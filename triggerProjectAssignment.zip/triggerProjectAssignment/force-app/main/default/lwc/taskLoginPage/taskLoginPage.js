import { LightningElement, track } from 'lwc';
import bootstrap from '@salesforce/resourceUrl/Bootstrap';
import { loadStyle, loadScript } from 'lightning/platformResourceLoader';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import CreateContactSign from '@salesforce/apex/LoginController.CreateContactSign';
import { NavigationMixin } from 'lightning/navigation';

export default class TaskLoginPage extends NavigationMixin(LightningElement) {
    @track firstName = '';
    @track lastName = '';
    @track phone = '';
    @track email = '';
    @track isLoading = false;

    handleInputChange(event) {
        const field = event.target.name;
        if (field === 'FirstName') {
            this.firstName = event.target.value;
        } else if (field === 'LastName') {
            this.lastName = event.target.value;
        } else if (field === 'Phone') {
            this.phone = event.target.value;
        } else if (field === 'Email') {
            this.email = event.target.value;
        }
    }

    handleClick() {
        this.isLoading = true;

        // Validate fields
        if (!this.firstName || !this.lastName || !this.phone || !this.email) {
            this.showToast('Error', 'All fields are required', 'error');
            this.isLoading = false;
            return;
        }

        // Validate email format
        if (!this.email.includes('@')) {
            this.showToast('Error', 'Invalid email format', 'error');
            this.isLoading = false;
            return;
        }

        // Create the contact via Apex
        CreateContactSign({
            firstName: this.firstName,
            lastName: this.lastName,
            phone: this.phone,
            email: this.email
        })
        .then(result => {
            this.isLoading = false;
            this.showToast('Success', 'Contact created successfully!', 'success');
            this.clearForm();

            // Redirect to the recruiter dashboard after successful creation
            this.redirectToDashboard();
        })
        .catch(error => {
            this.isLoading = false;
            this.showToast('Error', error.body.message, 'error');
            console.error('Error creating Contact:', error);
        });
    }

    redirectToDashboard() {
        // Navigate to a specific page (e.g., Recruiter Dashboard)
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: '/recruiter-dashboard' // Adjust this to the actual recruiter dashboard URL
            }
        });
    }

    clearForm() {
        this.firstName = '';
        this.lastName = '';
        this.phone = '';
        this.email = '';
        this.template.querySelectorAll('input').forEach(input => {
            input.value = '';
        });
    }

    showToast(title, message, variant) {
        const event = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant
        });
        this.dispatchEvent(event);
    }

    bootstrapJsInitialized = false;

    renderedCallback() {
        if (this.bootstrapJsInitialized) return;
        this.bootstrapJsInitialized = true;
        Promise.all([
            loadStyle(this, `${bootstrap}/bootstrap-5.3.3-dist/css/bootstrap.css`),
            loadScript(this, `${bootstrap}/bootstrap-5.3.3-dist/js/bootstrap.js`)
        ])
        .then(() => {
            console.log('Bootstrap css and js loaded.');
        })
        .catch(error => {
            console.log('Error loading Bootstrap:', error);
        });
    }
}