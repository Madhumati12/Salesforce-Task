import { LightningElement } from 'lwc';

export default class LifeCycleChildComponentExample extends LightningElement {
    constructor(){
       // super();
            console.log('call from child constructor');
    }
    connectedCallback(){
        console.log('call recevied from child connected call back');
    }
    renderedCallback(){
        console.log('call recevied from rendered call back');
    }
    disconnectedCallback(){
        console.log('call recevied from disconnected call back');
    }
}