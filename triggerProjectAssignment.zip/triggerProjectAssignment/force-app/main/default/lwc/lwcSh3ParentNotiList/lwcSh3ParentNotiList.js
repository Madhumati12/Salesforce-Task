import { LightningElement , track} from 'lwc';

export default class LwcSh3ParentNotiList extends LightningElement {
    @track notifications = [
        { id: 1, message: 'Notification 1' },
        { id: 2, message: 'Notification 2' },
        { id: 3, message: 'Notification 3' }
    ];

    handleDismiss(event) {
        const notificationId = event.detail.notificationId; 
        this.notifications = this.notifications.filter(notification => notification.id !== notificationId);
    }
}