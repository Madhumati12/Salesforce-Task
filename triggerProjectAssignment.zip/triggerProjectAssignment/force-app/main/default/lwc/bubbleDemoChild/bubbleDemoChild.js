import { LightningElement } from 'lwc';

export default class BubbleDemoChild extends LightningElement {
    handleClick(){
        console.log('Child component : Button clicked');
        const customEvent   = new CustomEvent('buttonclicked', {
            bubbles: true,
            composed: true
        });
        this.dispatchEvent(customEvent);
        }
}