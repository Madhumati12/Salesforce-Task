import { LightningElement, wire, track } from 'lwc';
import getAccDetails from '@salesforce/apex/lwcNo7ExpandCollapse.getAccDetails';

export default class LwcAssingNo7 extends LightningElement {
    @wire(getAccDetails) acc;
    @track error;
}