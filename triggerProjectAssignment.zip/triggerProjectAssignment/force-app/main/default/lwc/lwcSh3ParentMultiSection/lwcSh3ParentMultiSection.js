import { LightningElement,track } from 'lwc';

export default class LwcSh3ParentMultiSection extends LightningElement {
    @track sections = [
        { id: 1, title: 'Personal Information', description: 'Enter your personal details', isVisible: true },
        { id: 2, title: 'Address Details', description: 'Enter your address information', isVisible: false },
        { id: 3, title: 'Review & Submit', description: 'Review and submit your form', isVisible: false }
    ];

    handleSectionComplete(event) {
        const completedSectionTitle = event.detail.section;

        const currentIndex = this.sections.findIndex(section => section.title === completedSectionTitle);

        // If the next section exists, make it visible
        if (currentIndex !== -1 && currentIndex + 1 < this.sections.length) {
            this.sections[currentIndex].isVisible = false;
            this.sections[currentIndex + 1].isVisible = true;
        }
    }
}