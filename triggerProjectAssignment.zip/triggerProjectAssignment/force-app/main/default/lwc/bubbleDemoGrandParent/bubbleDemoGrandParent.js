import { LightningElement } from 'lwc';

export default class BubbleDemoGrandParent extends LightningElement {
    handleButtonClicked(event){
        console.log('GrandParent component : Event bubbled up');
    }
}