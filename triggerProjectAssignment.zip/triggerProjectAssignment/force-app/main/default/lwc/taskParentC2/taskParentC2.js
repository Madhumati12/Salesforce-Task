import { LightningElement, wire, track } from 'lwc';
import getFilteredJobs from '@salesforce/apex/LoginController.getFilteredJobs';
import { publish, MessageContext } from 'lightning/messageService';
import JOB_SELECTION_CHANNEL from '@salesforce/messageChannel/JobSelectedChannel__c';

export default class JobFilterComponent extends LightningElement {
    @track filteredJobs = [];
    @track startDate = '';
    @track endDate = '';
    @track selectedStatus = '';
    @track active = false;
    @track selectedPeriod = 'Today';
    @track error;
    @track selectedJob = null; 

    @wire(MessageContext)
    messageContext;

    statusOptions = [
        { label: 'Open', value: 'Open' },
        { label: 'Closed', value: 'Closed' },
    ];

    periodOptions = [
        { label: 'Today', value: 'Today' },
        { label: 'This Week', value: 'ThisWeek' },
        { label: 'Next Week', value: 'NextWeek' },
        { label: 'Next Month', value: 'NextMonth' },
        { label: 'Next Quarter', value: 'NextQuarter' }
    ];

    connectedCallback() {
        this.updateDate();
        this.fetchJob(); 
    }

    handleStartDateChange(event) {
        this.startDate = event.target.value;
        this.fetchJob();
    }

    handleEndDateChange(event) {
        this.endDate = event.target.value;
        this.fetchJob();
    }

    handleStatusChange(event) {
        this.selectedStatus = event.target.value;
        this.fetchJob();
    }

    handleActiveChange(event) {
        this.active = event.target.checked;
        this.fetchJob();
    }

    handlePeriodChange(event) {
        this.selectedPeriod = event.target.value;
        this.updateDate();
        this.fetchJob();
    }

    // handleFilterClick() {
    //     this.fetchJob();
    // }

    handleJobClick(event) {
        const jobId = event.currentTarget.dataset.id;
        console.log(jobId);

        // Find the selected job details
        this.selectedJob = this.filteredJobs.find(job => job.Id === jobId);
        console.log('Publisher: ',JSON.stringify(this.selectedJob));

        // Publish message with the job ID
        const payload = { selectedJob: this.selectedJob };
        publish(this.messageContext, JOB_SELECTION_CHANNEL, payload);
    }

    updateDate() {
        const today = new Date();
        let startDates = new Date(today);
        let endDates = new Date(today);

        switch (this.selectedPeriod) {
            case 'Today':
                startDates.setHours(0, 0, 0, 0);
                endDates.setHours(23, 59, 59, 999);
                break;
            case 'ThisWeek':
                const weekStart = new Date(today);
                weekStart.setDate(today.getDate() - today.getDay()); // Sunday
                const weekEnd = new Date(weekStart);
                weekEnd.setDate(weekStart.getDate() + 6); // Saturday
                startDates = weekStart;
                endDates = weekEnd;
                break;
            case 'NextWeek':
                const nextWeekStart = new Date(today);
                nextWeekStart.setDate(today.getDate() + (7 - today.getDay())); // Next Sunday
                const nextWeekEnd = new Date(nextWeekStart);
                nextWeekEnd.setDate(nextWeekStart.getDate() + 6); // Saturday
                startDates = nextWeekStart;
                endDates = nextWeekEnd;
                break;
            case 'NextMonth':
                startDates = new Date(today.getFullYear(), today.getMonth() + 1, 1);
                endDates = new Date(today.getFullYear(), today.getMonth() + 2, 0);
                break;
            case 'NextQuarter':
                const currentQuarter = Math.floor(today.getMonth() / 3) + 1;
                startDates = new Date(today.getFullYear(), currentQuarter * 3, 1);
                endDates = new Date(today.getFullYear(), (currentQuarter + 1) * 3, 0);
                break;
            default:
                startDates.setHours(0, 0, 0, 0);
                endDates.setHours(23, 59, 59, 999);
                break;
        }

        this.startDate = startDates.toISOString().split('T')[0];
        this.endDate = endDates.toISOString().split('T')[0];
    }

    fetchJob() {
        getFilteredJobs({
            startDates: this.startDate,
            endDates: this.endDate,
            isStatus: this.selectedStatus,
            IsActive: this.active
        })
        .then(result => {
            this.filteredJobs = result;
        })
        .catch(error => {
            console.error('Error fetching jobs:', error);
            this.error = error;
        });
    }
}