import { LightningElement,api,wire } from 'lwc';
import getRelatedContact from '@salesforce/apex/lwcNo1ConRelAcc.getRelatedContact';
export default class LwcAssing01 extends LightningElement {
    columns = [
         {
            label: 'First Name', fieldName: 'FirstName'},
        {
            label: 'Last Name',fieldName: 'LastName'},
        {
            label: 'Email', fieldName: 'Email', type: 'email'},
        {
            label: 'Phone', fieldName: 'Phone', type: 'phone'},
        {
            label: 'Designation', fieldName: 'Designation__c'},
        {
            label: 'Department', fieldName: 'Department'}
    ];
    @api recordId;
    @wire(getRelatedContact,{accId: '$recordId'})
        contacts=[];
        contacts({data,error}){
            if(data){
                this.contacts = data;
            }else{
                console.error('Error:', error);
            }
        }
}