import { LightningElement, api, track } from 'lwc';

export default class LwcSh2ChildPicklistNo3 extends LightningElement {
    @track _companyOptions = [];
    @track _selectedCompany = '';

    @api
    set companyOptions(options) {
        this._companyOptions = options;
    }

    get companyOptions() {
        return this._companyOptions;
    }

    @api
    set selectedCompany(value) {
        this._selectedCompany = value;
    }

    get selectedCompany() {
        return this._selectedCompany;
    }

    handleCompanyChange(event) {
        this._selectedCompany = event.detail.value;
        this.dispatchEvent(new CustomEvent('change', {
            detail: { value: this._selectedCompany }
        }));
    }
}



 //   @api parentValue; 
//     childOptions = {
//         'Team 1': [
//             { label: 'Select a Company', value: '' },
//             { label: 'Company 1', value: 'Company1' },
//             { label: 'Company 2', value: 'Company2' },
//             { label: 'Company 3', value: 'Company3' }
//         ],
//         'Team 2': [
//             { label: 'Select a Company', value: '' },
//             { label: 'Company 4', value: 'Company4' },
//             { label: 'Company 5', value: 'Company5' },
//             { label: 'Company 6', value: 'Company6' }
//         ],
//         'Team 3': [
//             { label: 'Select a Company', value: '' },
//             { label: 'Company 7', value: 'Company7' },
//             { label: 'Company 8', value: 'Company8' },
//             { label: 'Company 9', value: 'Company9' }
//         ]
//     };

//     @track filteredChildOptions = []; 
//     @track selectedChildValue = ''; 

//     @api
//     set parentValue(value) {
//         this._parentValue = value;
//         this.updateChildOptions(); 
//     }

//     get parentValue() {
//         return this._parentValue;
//     }

//     updateChildOptions() {
//         this.filteredChildOptions = this.childOptions[this._parentValue] || []; 
//         this.selectedChildValue = ''; 
//     }

//     handleChildChange(event) {
//         this.selectedChildValue = event.detail.value;
//     }
// }




// import { LightningElement, track, api } from 'lwc';

// export default class LwcSh2ChildPickilistNo3 extends LightningElement {
//     @track companyOptions = [];
//     @track selectedCompany = '';

//     @api
//     setCompanyOptions(companyOptions) {
//         this.companyOptions = companyOptions;
//         this.selectedCompany = ''; // Reset the selected company value
//     }

//     handleCompanyChange(event) {
//         this.selectedCompany = event.detail.value;
//     }
// }