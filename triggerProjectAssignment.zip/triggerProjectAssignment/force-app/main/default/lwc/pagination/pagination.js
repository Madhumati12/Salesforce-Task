import { LightningElement, api, track } from 'lwc';

export default class Pagination extends LightningElement {
    @api records = [];  
    @api pageSize = 10; 
    
    @track currentPage = 1;
    
    get totalPages() {
        return Math.ceil(this.records.length / this.pageSize);
    }

    get paginatedRecords() {
        const start = (this.currentPage - 1) * this.pageSize;
        const end = start + this.pageSize;
        return this.records.slice(start, end);
    }

    get isPreviousDisabled() {
        return this.currentPage <= 1;
    }

    get isNextDisabled() {
        return this.currentPage >= this.totalPages;
    }

    handlePrevious() {
        if (!this.isPreviousDisabled) {
            this.currentPage--;
            this.dispatchPageChangeEvent();
        }
    }

    handleNext() {
        if (!this.isNextDisabled) {
            this.currentPage++;
            this.dispatchPageChangeEvent();
        }
    }

    dispatchPageChangeEvent() {
        this.dispatchEvent(new CustomEvent('pagechange', {
            detail: { records: this.paginatedRecords }
        }));
    }

    connectedCallback() {
        this.dispatchPageChangeEvent();
    }
}