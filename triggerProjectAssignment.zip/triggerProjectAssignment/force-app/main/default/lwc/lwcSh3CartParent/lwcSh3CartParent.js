import { LightningElement, track } from 'lwc';

export default class LwcSh3CartParent extends LightningElement {
    @track cartItem = [
        { id: 1, name: 'Chips', price: 100, quantity: 1 },
        { id: 2, name: 'Mobile', price: 200, quantity: 2 },
        { id: 3, name: 'Laptop', price: 300, quantity: 3 }
    ];
    @track totalPrice = 0;

    connectedCallback() {
        this.calculateTotalPrice();
    }

    calculateTotalPrice() {
        this.totalPrice = this.cartItem.reduce((total, item) => {
            return total + (item.price * item.quantity);
        }, 0);
    }

    handleQuantityChange(event) {
        const { itemId, quantity } = event.detail;

        this.cartItem = this.cartItem.map(item => {
            if (item.id === itemId) {
                return { ...item, quantity: parseInt(quantity, 10) };
            }
            return item;
        });
        this.calculateTotalPrice();
    }
}