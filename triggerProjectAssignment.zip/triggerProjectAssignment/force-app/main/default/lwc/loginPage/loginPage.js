import { LightningElement } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';

export default class LoginPage extends NavigationMixin(LightningElement) {
    username = '';
    password = '';

    handleInputChange(event) {
        const field = event.target.label.toLowerCase();
        this[field] = event.target.value;
    }

    handleLogin() {
        // Validate credentials logic here
        // Navigate to the Recruiting Dashboard
        this[NavigationMixin.Navigate]({
            type: 'standard__component',
            attributes: {
                componentName: 'c__RecruitingDashboard'
            }
        });
    }
}