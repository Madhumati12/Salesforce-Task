import { LightningElement, track } from 'lwc';

export default class LwcSh3ChildCommentSection extends LightningElement {
    @track newComment = '';

    handleCommentChange(event) {
        this.newComment = event.target.value;
    }

    handleAddComment() {
        const commentEvent = new CustomEvent('addcomment', {
            detail: { comment: this.newComment }
        });
        this.dispatchEvent(commentEvent);
        this.newComment = ''; // Clear the comment field
    }
}