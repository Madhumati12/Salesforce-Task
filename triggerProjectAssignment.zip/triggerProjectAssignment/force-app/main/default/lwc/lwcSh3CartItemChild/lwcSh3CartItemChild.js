import { LightningElement, api } from 'lwc';

export default class LwcSh3CartItemChild extends LightningElement {
    @api itemId;
    @api itemName;
    @api price;
    @api quantity;

    get totalPrice() {
        return this.price * this.quantity;
    }

    handleQuantityChange(event) {
        const upQuantity = event.target.value;

        const quantityChangeEvent = new CustomEvent('quantitychange', {
            detail: { itemId: this.itemId, quantity: parseInt(upQuantity, 10) }
        });

        this.dispatchEvent(quantityChangeEvent);
    }
}