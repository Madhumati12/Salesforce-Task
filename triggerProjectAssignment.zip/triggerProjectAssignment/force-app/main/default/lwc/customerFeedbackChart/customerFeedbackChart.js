import { LightningElement, api, track } from 'lwc';
// import { loadScript } from 'lightning/platformResourceLoader';
// import CHART_JS from '@salesforce/resourceUrl/chartjs'; // Update this name to match your static resource name

export default class CustomerFeedbackChart extends LightningElement {
    // @api chartDataInput;
    // @api customerFeedbackData;

    // chartJs;
    // pieChart;

    // renderedCallback() {
    //     if (this.chartJs) {
    //         return;
    //     }
    //     this.loadChartJs();
    // }

    // loadChartJs() {
    //     loadScript(this, CHART_JS)
    //         .then(() => {
    //             this.chartJs = window.Chart;
    //             this.renderChart();
    //         })
    //         .catch(error => {
    //             console.error("Error loading Chart.js library", error);
    //         });
    // }

    // renderChart() {
    //     if (this.pieChart) {
    //         this.pieChart.destroy();
    //     }

    //     // Pie Chart Data (using provided data)
    //     const pieData = {
    //         labels: [
    //             'Red',
    //             'Blue',
    //             'Yellow'
    //         ],
    //         datasets: [{
    //             label: 'My First Dataset',
    //             data: [300, 50, 100],
    //             backgroundColor: [
    //                 'rgb(255, 99, 132)',
    //                 'rgb(54, 162, 235)',
    //                 'rgb(255, 205, 86)'
    //             ],
    //             hoverOffset: 4
    //         }]
    //     };

    //     // Rendering the Pie Chart
    //     const pieCtx = this.template.querySelector('canvas.pie-chart').getContext('2d');
    //     this.pieChart = new this.chartJs(pieCtx, {
    //         type: 'pie',
    //         data: pieData,
    //         options: {
    //             responsive: true,
    //             plugins: {
    //                 legend: {
    //                     position: 'top',
    //                 },
    //                 tooltip: {
    //                     callbacks: {
    //                         label: function(context) {
    //                             let label = context.label || '';
    //                             if (context.parsed !== null) {
    //                                 label += ': ' + context.parsed;
    //                             }
    //                             return label;
    //                         }
    //                     }
    //                 }
    //             }
    //         }
    //     });
    // }
}
