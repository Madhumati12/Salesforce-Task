import { LightningElement, track } from 'lwc';

export default class LwcSh3ParentUserProfileList extends LightningElement {
    @track userProfile = [
        { id: 1, name: 'John', email: 'john@gmail.com' },
        { id: 2, name: 'Jonny', email: 'jonny@gmail.com' }
    ];

    // handleProfileUpdate(event) {
    //     const { id, name, email } = event.detail;
    //     const profileUpdate = this.userProfile.find(profile => profile.id === id);
    //     profileUpdate.name = name;
    //     profileUpdate.email = email;
    //     console.log('Name: ' + name + ' Email: ' + email);
    // }

    handleProfileUpdate(event) {
        const { id, name, email } = event.detail;
        const profileUpdate = this.userProfile.find(profile => profile.id === id);
    
        if (profileUpdate) {
            profileUpdate.name = name;
            profileUpdate.email = email;
            console.log('Profile updated:', profileUpdate);
        } else {
            console.error('Profile not found for id:', id);
        }
    }
    
}