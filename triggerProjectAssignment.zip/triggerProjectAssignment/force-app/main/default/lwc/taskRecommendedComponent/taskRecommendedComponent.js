// import { LightningElement, wire, track } from 'lwc';
// import conList from '@salesforce/apex/LoginController.conList';

// export default class TaskRecommendedComponent extends LightningElement {

//     @track contacts = [];
//     @track selectedContacts = [];

//     columns = [
//         { label: 'Select', type: 'checkbox', fieldName: 'select' },
//         { label: 'Profile', fieldName: 'Profile__c', type: 'text' },
//         { label: 'First Name', fieldName: 'FirstName', type: 'text' },
//         { label: 'Last Name', fieldName: 'LastName', type: 'text' },
//         { label: 'Email', fieldName: 'Email', type: 'email' },
//         { label: 'Phone', fieldName: 'Phone', type: 'phone' },
//         { label: 'Status', fieldName: 'Status__c', type: 'text' },
//         { label: 'City', fieldName: 'City__c', type: 'text' },
//         { label: 'Skills', fieldName: 'Skills__c', type: 'text' }
//     ];

//     @wire(conList)
//     wiredContacts({ data, error }) {
//         if (data) {
//             this.contacts = data;
//         } else if (error) {
//             console.error(error);
//         }
//     }

//     handleRowSelection(event) {
//         this.selectedContacts = event.detail.selectedRows;
//     }

//     handleAddClick() {
//         const addEvent = new CustomEvent('addcontacts', {
//             detail: this.selectedContacts
//         });
//         this.dispatchEvent(addEvent);
//     }
// }


import { LightningElement, wire, track } from 'lwc';
import jobList from '@salesforce/apex/LoginController.getFilteredJobs';

 export default class TaskRecommendedComponent extends LightningElement {



    @track filteredJobs = [];
    @track startDate = '';
    @track endDate = '';
    @track selectedStatus = '';
    @track active = false;
    @track selectedPeriod = 'Today';  // Default to "Today"
    
    // Picklist options for status and schedule period
    statusOptions = [
        { label: 'Open', value: 'Open' },
        { label: 'Closed', value: 'Closed' },
        { label: 'In Progress', value: 'In Progress' }
    ];

    periodOptions = [
        { label: 'Today', value: 'Today' },
        { label: 'This Week', value: 'This Week' },
        { label: 'This Month', value: 'This Month' },
        { label: 'All Time', value: 'All Time' }
    ];

    // Event Handlers for Filter Changes
    handleStartDateChange(event) {
        this.startDate = event.target.value;
    }

    handleEndDateChange(event) {
        this.endDate = event.target.value;
    }

    handleStatusChange(event) {
        this.selectedStatus = event.target.value;
    }

    handleActiveChange(event) {
        this.active = event.target.checked;
    }

    handlePeriodChange(event) {
        this.selectedPeriod = event.target.value;
    }

    handleFilterClick() {
        // Call Apex method to fetch the filtered jobs based on filter criteria
        jobList({
            startDate: this.startDate,
            endDate: this.endDate,
            status: this.selectedStatus,
            active: this.active,
            schedulePeriod: this.selectedPeriod
        })
        .then(result => {
            this.filteredJobs = result;
        })
        .catch(error => {
            console.error('Error fetching jobs:', error);
        });
    }
}

















//     // @track candidates = [];
//     // @track error;

//     // columns = [
//     //     { label: 'Profile', fieldName: 'Name' },
//     //     { label: 'Email', fieldName: 'Email__c' },
//     //     { label: 'Mobile', fieldName: 'Mobile__c' },
//     //     { label: 'Status', fieldName: 'Status__c' },
//     //     { label: 'City', fieldName: 'City__c' }
//     // ];

//     // @wire(conList)
//     // wiredCandidates({ error, data }) {
//     //     if (data) {
//     //         this.candidates = data;
//     //     } else if (error) {
//     //         this.error = error;
//     //     }
//     // }