import { LightningElement , api} from 'lwc';

export default class LwcSh3ChildFormSection extends LightningElement {
    @api title;       
    @api description; 

    handleComplete() {
        const completeEvent = new CustomEvent('sectioncomplete', {
            detail: { section: this.title }
        });
        this.dispatchEvent(completeEvent);
    }
}