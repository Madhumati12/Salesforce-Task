import { LightningElement, track, api, wire } from 'lwc';
import oppCloseDate from '@salesforce/apex/lwcNo8OppCloseDate.oppCloseDate';
import upOppCloseDate from '@salesforce/apex/lwcNo8OppCloseDate.upOppCloseDate';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';

export default class LwcAssingNo8 extends LightningElement {
    @api recordId; 
    @track closeDate;
    @track error;

    @wire(oppCloseDate, { oppId: '$recordId' })
    wiredOpportunity({ error, data }) {
        if (data) {
            this.closeDate = data.CloseDate;
        } else if (error) {
            this.error = error;
        }
    }

    handleDateChange(event) {
        this.closeDate = event.target.value;
    }

    handleSave() {
        upOppCloseDate({ oppId: this.recordId, newCloseDate: this.closeDate })
            .then(() => {
                this.showToast('Success', 'Opportunity Close Date updated successfully.', 'success');
            })
            .catch(error => {
                this.showToast('Error', error.body.message, 'error');
            });
    }

    handleCancel() {
        this.closeDate = '';
    }

    showToast(title, message, variant) {
        const evt = new ShowToastEvent({
            title: title,
            message: message,
            variant: variant,
        });
        this.dispatchEvent(evt);
    }
}