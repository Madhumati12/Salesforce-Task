import { LightningElement, wire, track } from 'lwc';
import listOfContact from '@salesforce/apex/lwcContacts.listOfContact';

export default class LwcSh2ListOfConNo2 extends LightningElement {
    @track recordId = [];
    @track filterCon = [];

    searchItem = '';
    sortDirection = 'asc';
    sortBy = 'FirstName';
    showSearch = true;

    @wire(listOfContact)
    wiredContacts({ data, error }) {
        if (data) {
            this.recordId = data;  
            this.filterCon = [...this.recordId];
        } else if (error) {
            console.log('Error fetching contacts:', error);
        }
    }

    handleSort(event) {
        const { fieldName, sortDirection } = event.detail;
        this.sortDirection = sortDirection;
        this.sortBy = fieldName;
        this.sortContact();
    }

    sortContact() {
        const isAsc = this.sortDirection === 'asc';
        this.filterCon = [...this.filterCon].sort((a, b) => {
            const field1 = a[this.sortBy] ? a[this.sortBy].toLowerCase() : '';
            const field2 = b[this.sortBy] ? b[this.sortBy].toLowerCase() : '';
            return isAsc ? (field1 > field2 ? 1 : -1) : (field1 < field2 ? 1 : -1);
        });
    }

    handleKeyChange(event) {
        this.searchItem = event.target.value.toLowerCase();
        this.filterContacts();
    }

    handleSubmitChange(){
        this.showSearch = !this.showSearch;
    }    

    filterContacts() {
        this.filterCon = this.recordId.filter(con => {
            return con.FirstName.toLowerCase().includes(this.searchItem) || 
                   con.LastName.toLowerCase().includes(this.searchItem);
        });
        this.sortContact();
    }
}