import { LightningElement } from 'lwc';

export default class LifeCycleHooksExample extends LightningElement {
    constructor(){
        super();
        console.log('Call recieved from constructor');
    }
    connectedCallback(){
        console.log('Call recieved from connected call back');
    }
    renderedCallback(){
        console.log('Call recieved from render call back');
    }
    errorCallback(){
        console.log('call recieved from error call back');
    }
}