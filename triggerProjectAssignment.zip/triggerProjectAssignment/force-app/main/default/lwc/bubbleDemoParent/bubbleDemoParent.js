import { LightningElement } from 'lwc';

export default class BubbleDemoParent extends LightningElement {
    handleButtononClicked(event){
        console.log('Parent component: Event bubbled up');
    }
}