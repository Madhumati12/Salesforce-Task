import { LightningElement, track, api, wire } from 'lwc';
import { updateRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import upOppInline from '@salesforce/apex/lwcNo5InlineOpp.upOppInline';
import { refreshApex } from '@salesforce/apex';

import NAME_FIELD from '@salesforce/schema/Opportunity.Name';
import STAGENAME_FIELD from '@salesforce/schema/Opportunity.StageName';
import CLOSEDATE_FIELD from '@salesforce/schema/Opportunity.CloseDate';
import ID_FIELD from '@salesforce/schema/Opportunity.Id';



const columns = [
    { label: 'Id', fieldName: ID_FIELD.fieldApiName, type: 'text', editable: false },
            { label: 'Name', fieldName: NAME_FIELD.fieldApiName, type: 'text', editable: true },
            { label: 'Stage Name', fieldName: STAGENAME_FIELD.fieldApiName, type: 'text', editable: true },
            { label: 'Close Date', fieldName: CLOSEDATE_FIELD.fieldApiName, type: 'date', editable: true }
];

    export default class LwcAssingNo5 extends LightningElement {

        @api recordId;
        @track opportunities =[];
        @track draftValues = [];
        
        column = columns;
        @wire(upOppInline)
          wiredOpportunities({ error, data }) {
           // debugger;
        if (data) {
            this.opportunities = data;
            this.error = undefined;
        } else if (error) {
            this.error = error;
            this.opportunities = undefined;
            this.showToast('Error', error.body.message, 'error');
        }
    }

    // @wire(upOppInline, { accId: '$recordId' })
    // opportunities;

    async handleSave(event) {
        const updateFields = event.detail.draftValues.map(draft => ({
            Id: draft.Id,
            Name: draft.Name,
            StageName: draft.StageName,
            CloseDate: draft.CloseDate
        }));
       const notifyChangeIds= updateFields.map(row => ({ recordId: row.Id }));

       try {

        const result = await updateRecord({ data: updateFields });
            console.log('Apex update result:', JSON.stringify(result));
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Success',
                    message: 'Opportunity updated successfully!',
                    variant: 'success'
                })
            );
        
        notifyRecordUpdateAvailable(notifyChangeIds);
        await refreshApex(this.opportunities);
        this.draftValues = [];
       }
       
       catch(error){
        this.dispatchEvent(
          new ShowToastEvent({
            title: 'Error',
            message: error.body.message,
            variant: 'error'
          })
        );
       }
    }
}

// import { LightningElement, track, api, wire } from 'lwc';
// import { updateRecord } from 'lightning/uiRecordApi';
// import { ShowToastEvent } from 'lightning/platformShowToastEvent';
// import upOppInline from '@salesforce/apex/lwcNo5InlineOpp.upOppInline';
// import { refreshApex } from '@salesforce/apex';

// export default class LwcAssingNo5 extends LightningElement {
//     columns = [
//         {label: 'Name', fieldName: 'Name', editable: true},
//         {label: 'Stage Name', fieldName: 'StageName', editable: true},
//         {label: 'Close Date', fieldName: 'CloseDate', type: 'date', editable: true}
//     ];
    
//     @track opportunities = [];
//     @track draftValues = [];

//     @wire(upOppInline)
//     wiredOpportunities({ error, data }) {
//         if (data) {
//             this.opportunities = data;
//         } else if (error) {
//             this.showToast('Error', error.body.message, 'error');
//         }
//     }

//     handleSave(event) {
//         const fields = {};
//         event.detail.draftValues.forEach(draft => {
//             fields.Id = draft.Id;
//             if (draft.Name) fields.Name = draft.Name;
//             if (draft.StageName) fields.StageName = draft.StageName;
//             if (draft.CloseDate) fields.CloseDate = draft.CloseDate;
            
//             const recordInput = { fields };
//             updateRecord(recordInput)
//                 .then(() => {
//                     this.showToast('Success', 'Opportunity updated successfully!', 'success');
//                     this.draftValues = [];
//                     return refreshApex(this.opportunities);
//                 })
//                 .catch(error => {
//                     this.showToast('Error updating record', error.body.message, 'error');
//                 });
//         });
//     }

//     showToast(title, message, variant) {
//         this.dispatchEvent(
//             new ShowToastEvent({
//                 title: title,
//                 message: message,
//                 variant: variant,
//             }),
//         );
//     }
// }