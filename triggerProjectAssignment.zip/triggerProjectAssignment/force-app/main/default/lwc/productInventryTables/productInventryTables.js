import { LightningElement, api, track } from 'lwc';
import getFilteredInventory from '@salesforce/apex/TaskDashboardController.getFilteredInventory';

export default class ProductInventryTables extends LightningElement {
//     @api productCategory;
//     @api region;
//     @api dateRange;

//     @track inventoryData = [];
//     @track error;
//     @track currentPage = 1;
//     @track pageSize = 10;
//     @track totalRecords;
//     @track paginatedData = [];

//     columns = [
//         { label: 'Product Name', fieldName: 'Product_Name__c' },
//         { label: 'Available Quantity', fieldName: 'Quantity_Available__c', type: 'number' },
//         { label: 'Region', fieldName: 'Region__c' }
//     ];

//     connectedCallback() {
//         this.fetchInventoryData(); // Call fetch method on component load
//     }

//     @api
// fetchInventoryData() {
//     console.log('Fetching inventory data with:', {
//         productCategory: this.productCategory,
//         region: this.region,
//         dateRange: this.dateRange
//     });

//     getFilteredInventory({
//         productCategory: this.productCategory,
//         region: this.region,
//         dateRange: this.dateRange
//     })
//     .then(result => {
//         console.log('Inventory Data:', result); // Log the result for debugging
//         this.inventoryData = result;
//         this.totalRecords = result.length;
//         this.error = undefined;
//         this.updatePagination();
//     })
//     .catch(error => {
//         console.error('Error fetching inventory data:', error); // Log error details
//         this.error = error.body.message;
//         // this.inventoryData = undefined;
//     });
// }


//     updatePagination() {
//         const startIndex = (this.currentPage - 1) * this.pageSize;
//         const endIndex = this.currentPage * this.pageSize;
//         this.paginatedData = this.inventoryData.slice(startIndex, endIndex);
//     }

//     handleNextPage() {
//         if (this.currentPage < Math.ceil(this.totalRecords / this.pageSize)) {
//             this.currentPage++;
//             this.updatePagination();
//         }
//     }

//     handlePrevPage() {
//         if (this.currentPage > 1) {
//             this.currentPage--;
//             this.updatePagination();
//         }
//     }

//     handleFirstPage() {
//         this.currentPage = 1;
//         this.updatePagination();
//     }

//     handleLastPage() {
//         this.currentPage = Math.ceil(this.totalRecords / this.pageSize);
//         this.updatePagination();
//     }
}
