import { LightningElement, api, track, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
import getMatchingContactsAndJobs from '@salesforce/apex/LoginController.getMatchingContactsAndJobs';
import createJobApplicants from '@salesforce/apex/LoginController.createJobApplicants';
import { refreshApex } from '@salesforce/apex';
import updateCandidate from '@salesforce/apex/LoginController.updateCandidate';
// import LightningDatatable from 'lightning/datatable';
// import customImage from './customImage.html';


export default class TaskRecommendedC4 extends NavigationMixin(LightningElement) {
    @track recommendedCandidates = [];
    @track noRecommendedCandidates = false;
    @track isSelectAllChecked = false;
    selectedCandidates = new Set();
    @track jobData;
    @track wiredInfo;
    @track jobId;
    selectedRows = [];
    @track currentPage = 1;
    @track totalRecords;
    @track showModal = false;
    @track pageSize = 10;
    @track selectedCandidate = {};

    columns = [
        // {
        //     label: 'Profile',
        //     fieldName: 'Profile__c',
        //     type: 'customImage',
        //     // typeAttributes: {
        //     //     width: 10,
        //     //     height: 10
        //     // }
        // },
        {
            label: 'Profile Picture',
            fieldName: 'Profile__c',
            type: 'customImage',
        },
        { label: 'Name', fieldName: 'FirstName' },
        { label: 'Last Name', fieldName: 'LastName' },
        { label: 'Email', fieldName: 'Email' },
        { label: 'Phone', fieldName: 'Phone' },
        { label: 'Skills', fieldName: 'Skills__c' },
        {
            type: 'action',
            typeAttributes: { rowActions: this.getRowActions }
        }
    ];

    // static customTypes = {
    //     customImageCell: {
    //         template: customImage,
    //         // standardCellLayout: true,
    //         // typeAttributes: ['width', 'height']
    //     }
    // }

    @api
    get record() {
        return this.jobData;
    }

    set record(value) {
        this.jobData = value;
    }

    @wire(getMatchingContactsAndJobs, { skills: '$jobData.Skills__c' })
    wiredData(result) {
        this.wiredInfo = result;
        if (result.data) {
            this.recommendedCandidates = result.data;
            this.noRecommendedCandidates = result.data.length === 0;
        } else if (result.error) {
            this.recommendedCandidates = [];
            this.noRecommendedCandidates = true;
        }
    }

    handleNextPage() {
        this.currentPage += 1;
    }

    handlePreviousPage() {
        if (this.currentPage > 1) {
            this.currentPage -= 1;
        }
    }

    getRowActions(row, doneCallback) {
        const actions = [
            {
                label: 'Edit',
                name: 'edit_candidate',
                iconName: 'utility:edit',
            }
        ];
        doneCallback(actions);
    }

    handleRowAction(event) {
        const actionName = event.detail.action.name;
        const row = event.detail.row;
        
        if (actionName === 'edit_candidate') {
            this.selectedCandidate = { ...row };
            this.showModal = true;
        }
    }

    handleRowSelection(event) {
        this.selectedRows = event.detail.selectedRows.map(row => row.Id);
    }

    removeSelectedContactsFromTable() {
        const selectedIds = this.selectedRows.map(row => row.Id);
        this.filteredData = this.filteredData.filter(contact => !selectedIds.includes(contact.Id));
        this.selectedRows = []; 
    }

    handleInputChange(event) {
        const field = event.target.dataset.id;
        this.selectedCandidate = {
            ...this.selectedCandidate,
            [field]: event.target.value
        };
    }

    handleModalSave() {
        updateCandidate({ candidate: this.selectedCandidate })
            .then(() => {
                const index = this.recommendedCandidates.findIndex(candidate => candidate.Id === this.selectedCandidate.Id);
                if (index !== -1) {
                    this.recommendedCandidates[index] = this.selectedCandidate;
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Success',
                            message: 'Candidate updated successfully.',
                            variant: 'success'
                        })
                    );
                }
                this.showModal = false;
                return refreshApex(this.wiredInfo);
            })
            .catch(error => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error',
                        message: error.body.message,
                        variant: 'error'
                    })
                );
            });
    }

    handleModalClose() {
        this.showModal = false;
    }

    handleCreateJobApplicants() {
        if (!this.jobData.Id) {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error',
                    message: 'Job ID is missing.',
                    variant: 'error'
                })
            );
            return;
        }
    
        if (this.selectedRows.length === 0) {
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error',
                    message: 'Please select at least one candidate.',
                    variant: 'error'
                })
            );
            return;
        }
    
        createJobApplicants({ jobId: this.jobData.Id, candidateIds: this.selectedRows })
            .then(() => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Success',
                        message: 'Candidates added to job application successfully.',
                        variant: 'success'
                    })
                );
                this.template.querySelector('c-custom-data-table').selectedRows = [];
                return refreshApex(this.wiredInfo);
            })
            .then(() => {
                this.dispatchEvent(new CustomEvent('refreshdata', {
                    detail: { flag: true }
                }));
            })
            .catch(error => {
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error',
                        message: error.body.message,
                        variant: 'error'
                    })
                );
            });
    }
}
