import { LightningElement, api } from 'lwc';

export default class LwcSh3ChildUserProfileItem extends LightningElement {
    @api id;
    @api name;
    @api email;

    localName;
    localEmail;

    connectedCallback() {
        console.log('Name:', this.name, 'Email:', this.email);
        this.localName = this.name;
        this.localEmail = this.email;
    }
    
    handleNameChange(event) {
        this.localName = event.target.value;
    }

    handleEmailChange(event) {
        this.localEmail = event.target.value;
    }

    handleSave() {
        const profileUpdateEvent = new CustomEvent('profileupdate', {
            detail: {
                id: this.id,
                name: this.localName,
                email: this.localEmail
            }
        });
        this.dispatchEvent(profileUpdateEvent);
    }
}