import { LightningElement, track } from 'lwc';

export default class LwcSh3ParentPostSection extends LightningElement {
    @track comments = [];

    handleCommentAdd(event) {
        const newComment = event.detail.comment;
        // Assign a unique id to each comment
        const commentWithId = { id: Date.now(), text: newComment };
        this.comments = [...this.comments, commentWithId];
    }
}