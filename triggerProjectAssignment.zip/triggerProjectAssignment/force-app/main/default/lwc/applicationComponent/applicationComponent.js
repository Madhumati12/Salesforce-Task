import { LightningElement, track } from 'lwc';

export default class ApplicationComponent extends LightningElement {
    @track applications = [
        { id: '1', profile: 'John Doe', email: 'john@example.com', mobile: '123-456-7890', status: 'Applied' },
        // Add more application data
    ];

    columns = [
        { label: 'Profile', fieldName: 'profile' },
        { label: 'Email', fieldName: 'email' },
        { label: 'Mobile', fieldName: 'mobile' },
        { label: 'Status', fieldName: 'status' }
    ];
}