import { LightningElement,api, wire } from 'lwc';
import getOpp from '@salesforce/apex/lwcNo3GetOpp.getOpp';

export default class LwcAssingNo3 extends LightningElement {

    columns = [
{ label: 'First Name', fieldName: 'Name' },
{ label: 'Stage Name', fieldName: 'StageName' },
{ label: 'Amount', fieldName: 'Amount'},
];

@api recordId;

@wire (getOpp, {accId : '$recordId'})
opportunities = [];
opportunities({data,error}){
if(data){
this.opportunities = data;
}else{
console.error('Error:', error);
}
}
}