import { LightningElement, track, wire } from 'lwc';
import accPagination from '@salesforce/apex/lwcPaginationNo1.accPagination';

const COLUMNS = [
    { label: 'Name', fieldName: 'Name', },
    { label: 'Phone', fieldName: 'Phone', },
];

export default class ComponentOfPaginationNo1 extends LightningElement {
    @track paginatedRecords=[];
    @track accRecords = [];

    columns = COLUMNS; 

    //accRecords = []; 

    @wire(accPagination)
    wiredAccount({ error, data }) {
        if (data) {
            this.accRecords = data;
        } else if (error) {
            this.error = error;
        }
    }

    handlePageChange(event) {
        this.paginatedRecords = event.detail.records;
    }
}