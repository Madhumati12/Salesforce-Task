import { LightningElement, track } from 'lwc';

export default class LwcSh2ParentPicklistNo3 extends LightningElement {
    @track teamOptions = [
        { label: 'Select a Team', value: '' },
        { label: 'Team 1', value: 'Team 1' },
        { label: 'Team 2', value: 'Team 2' },
        { label: 'Team 3', value: 'Team 3' }
    ];

    @track companyOptions = [];
    @track selectedTeam = '';
    @track selectedCompany = '';

    handleTeamChange(event) {
        this.selectedTeam = event.detail.value;
        this.updateCompanyOptions();
    }

    updateCompanyOptions() {
        switch (this.selectedTeam) {
            case 'Team 1':
                this.companyOptions = [
                    { label: 'Select a Company', value: '' },
                    { label: 'Dell', value: 'Dell' },
                    { label: 'Hp', value: 'Hp' }
                ];
                break;
            case 'Team 2':
                this.companyOptions = [
                    { label: 'Select a Company', value: '' },
                    { label: 'Tesla', value: 'Tesla' },
                    { label: 'Audi', value: 'Audi' }
                ];
                break;
            case 'Team 3':
                this.companyOptions = [
                    { label: 'Select a Company', value: '' },
                    { label: 'Isro', value: 'Isro' },
                    { label: 'Nasa', value: 'Nasa' }
                ];
                break;
            default:
                this.companyOptions = [];
        }
        this.selectedCompany = '';
    }

    handleCompanyChange(event) {
        this.selectedCompany = event.detail.value;
    }
}



// import { LightningElement, track, wire } from 'lwc';
// import getTeamOptions from '@salesforce/apex/lwcPicklistControllerSh2No3.getTeamOptions';
// import getCompanyOptions from '@salesforce/apex/lwcPicklistControllerSh2No3.getCompanyOptions';

// export default class ParentPicklist extends LightningElement {
//   @track teamOptions = [];
//   @track companyOptions = [];
//   @track selectedTeam = '';

//   @wire(getTeamOptions)
//   wiredTeamOptions({ data, error }) {
//     if (data) {
//       this.teamOptions = data;
//     } else if (error) {
//       console.error('Error fetching team options:', error);
//     }
//   }

//   handleTeamChange(event) {
//     this.selectedTeam = event.detail.value;

//     getCompanyOptions({ selectedTeam: this.selectedTeam })
//       .then(result => {
//         this.companyOptions = result;
//         const childComponent = this.template.querySelector('c-child-picklist');
//         if (childComponent) {
//           childComponent.setCompanyOptions(this.companyOptions);
//         }
//       })
//       .catch(error => {
//         console.error('Error fetching company options:', error);
//       });
//   }
// }