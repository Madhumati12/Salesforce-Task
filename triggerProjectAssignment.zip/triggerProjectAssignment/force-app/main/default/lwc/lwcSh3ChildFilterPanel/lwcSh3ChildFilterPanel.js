import { LightningElement, track } from 'lwc';

export default class LwcSh3ChildFilterPanel extends LightningElement {
    @track createdDate;
    @track status;

    statusOptions = [
        { label: 'Open', value: 'open' },
        { label: 'Closed', value: 'closed' }
    ];

    handleCreatedDateChange(event) {
        this.createdDate = event.target.value;
    }

    handleStatusChange(event) {
        this.status = event.target.value;
    }

    handleApplyFilter() {
        const filterEvent = new CustomEvent('filterchange', {
            detail: {
                createdDate: this.createdDate,
                status: this.status
            }
        });
        this.dispatchEvent(filterEvent);
    }
}