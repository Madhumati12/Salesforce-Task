import { LightningElement, track } from 'lwc';
// import getSalesPerformance from '@salesforce/apex/TaskDashboardController.getSalesPerformance';
// import getCustomerFeedback from '@salesforce/apex/TaskDashboardController.getCustomerFeedback';
// import getProductInventory from '@salesforce/apex/TaskDashboardController.getProductInventory'; // Import the method
// import { ShowToastEvent } from 'lightning/platformShowToastEvent';
// import BOOTSTRAP from '@salesforce/resourceUrl/bootstrap';
// import { loadStyle } from 'lightning/platformResourceLoader';
// import getFilteredData from '@salesforce/apex/TaskDashboardController.getFilteredData';

 export default class Dashboard extends LightningElement {
//     @track dateRange = ''; 
//     @track productCategory = ''; 
//     @track region = ''; 
//     @track salesPerformanceData = [];
//     @track customerFeedbackData = [];
//     @track startDate = '';
//     @track endDate = '';
//     @track filteredData = [];
//     @track error;

//     chart;

//     get dateRangeOptions() {
//         return [
//             { label: 'Today', value: 'today' },
//             { label: 'This Week', value: 'thisWeek' },
//             { label: 'This Year', value: 'thisYear' },
//             { label: 'This Month', value: 'thisMonth' }

//         ];
//     }

//     get productCategoryOptions() {
//         return [
//             { label: 'Mobile', value: 'mobile' },
//             { label: 'Car', value: 'car' },
//             { label: 'Laptop', value: 'laptop' },
//             { label: 'TV', value: 'tv' }
//         ];
//     }

//     get regionOptions() {
//         return [
//             { label: 'North', value: 'north' },
//             { label: 'South', value: 'south' },
//             { label: 'East', value: 'east' },
//             { label: 'West', value: 'west' }
//         ];
//     }

//     connectedCallback() {
//         loadStyle(this, BOOTSTRAP + '/bootstrap.min.css');
//         this.applyFilters();
//         this.updateDataPeriodically();
//     }

//     handleDateRangeChange(event) {
//         this.dateRange = event.detail.value;
//     }

//     handleProductCategoryChange(event) {
//         this.productCategory = event.detail.value;

//     }

//     handleRegionChange(event) {
//         this.region = event.detail.value;
        
//     }

//     applyFilters() {
//         getSalesPerformance({
//             dateRange: this.dateRange,
//             productCategory: this.productCategory,
//             region: this.region
//         })
//         .then(result => {
//             this.filteredData = result;
//             this.error = undefined;
//             this.updateChart(); // If you want to update the chart with the filtered data
//         })
//         .catch(error => {
//             this.error = error;
//             this.filteredData = undefined;
//             this.showErrorToast('Error fetching sales performance data', error.body.message);
//         });

//         const inventoryTable = this.template.querySelector('c-product-inventory-table');
//         if (inventoryTable) {
//             inventoryTable.fetchInventoryData();
//         } else {
//             console.warn('Product Inventory Table component not found.');
//         }
        
//         this.fetchCustomerFeedbackData();
//     }
    
//     updateDataPeriodically() {
//         setInterval(() => {
//             this.applyFilters();
//         }, 10000); // Update every 10 seconds
//     }

    // applyFilters() {
    //     this.fetchSalesPerformanceData();
    //     this.fetchCustomerFeedbackData();
    // }

    // fetchSalesPerformanceData() {
    //     console.log('Fetching data with: ', this.getStartDate(), this.getEndDate(), this.productCategory, this.region);
    //     getSalesPerformance({
    //         dateRange: this.dateRange,
    //         productCategory: this.productCategory,
    //         region: this.region
    //     })
    //     .then(result => {
    //         console.log('Sales Performance Data:', result); // Log data to check
    //         this.salesPerformanceData = result || [];
    //         this.updateChart();
    //     })
    //     .catch(error => {
    //         console.error('Error fetching sales performance data:', error);
    //         const errorMessage = error.body ? error.body.message : JSON.stringify(error);
    //         this.showErrorToast('Error fetching sales performance data', errorMessage);
    //     });
    // }
    

    // fetchCustomerFeedbackData() {
    //     getCustomerFeedback()
    //     .then(result => {
    //         this.customerFeedbackData = result || [];
    //     })
    //     .catch(error => {
    //         const errorMessage = error.body ? error.body.message : 'An error occurred';
    //         this.showErrorToast('Error fetching customer feedback data', errorMessage);
    //     });
    // }

    // updateChart() {
    //     const canvas = this.template.querySelector('canvas.chart');
    //     if (this.chart) {
    //         this.chart.destroy(); // Destroy the previous chart instance before creating a new one
    //     }
        
    //     if (this.salesPerformanceData.length > 0) {
    //         this.chart = new Chart(canvas, {
    //             type: 'line', // or 'bar', 'pie', etc.
    //             data: {
    //                 labels: this.salesPerformanceData.map(record => record.Sales_Date__c),
    //                 datasets: [{
    //                     label: 'Sales Amount',
    //                     data: this.salesPerformanceData.map(record => record.Sales_Amount__c),
    //                     borderColor: 'rgba(75, 192, 192, 1)',
    //                     borderWidth: 2
    //                 }]
    //             },
    //             options: {
    //                 responsive: true,
    //                 maintainAspectRatio: false,
    //                 scales: {
    //                     x: {
    //                         type: 'time',
    //                         time: {
    //                             unit: 'day'
    //                         }
    //                     },
    //                     y: {
    //                         beginAtZero: true
    //                     }
    //                 }
    //             }
    //         });
    //     } else {
    //         console.log('No sales performance data available to display on the chart.');
    //         // Optionally, you can also display a message on the UI indicating no data is available
    //     }
    // }

    // getStartDate() {
    //     const today = new Date();
    //     let startDates = new Date(today);
    //     let endDates = new Date(today);
    //     // const today = new Date();
    //     if (this.dateRange === 'last7days') {
    //         return new Date(today.setDate(today.getDate() - 7)).toISOString().split('T')[0];
    //     } else if (this.dateRange === 'last30days') {
    //         return new Date(today.setDate(today.getDate() - 30)).toISOString().split('T')[0];
    //     } else {
    //         return new Date(today.getFullYear(), 0, 1).toISOString().split('T')[0];
    //     }
    // }

    // getEndDate() {
    //     return new Date().toISOString().split('T')[0];
    // }

    // showErrorToast(title, message) {
    //     const event = new ShowToastEvent({
    //         title: title,
    //         message: message,
    //         variant: 'error',
    //     });
    //     this.dispatchEvent(event);
    // }
}
