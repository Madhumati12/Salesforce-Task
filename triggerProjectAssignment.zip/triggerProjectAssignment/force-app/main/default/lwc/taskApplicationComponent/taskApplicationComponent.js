import { LightningElement, wire, track } from 'lwc';

export default class TaskApplicationComponent extends LightningElement {
    @track applications = [];

    columns = [
        { label: 'Profile', fieldName: 'Profile__c', type: 'image', typeAttributes: { alt: 'Profile Picture', height: 50, width: 50 } },

      //  { label: 'Profile', fieldName: 'Profile__c', type: 'text' },
        { label: 'First Name', fieldName: 'FirstName', type: 'text' },
        { label: 'Last Name', fieldName: 'LastName', type: 'text' },
        { label: 'Email', fieldName: 'Email', type: 'email' },
        { label: 'Phone', fieldName: 'Phone', type: 'phone' },
        { label: 'Status', fieldName: 'Status__c', type: 'text' },
        { label: 'City', fieldName: 'City__c', type: 'text' },
        { label: 'Skills', fieldName: 'Skills__c', type: 'text' }
    ];

    handleAddContacts(event) {
        const selectedContacts = event.detail;
        this.applications = [...this.applications, ...selectedContacts];
    }

    connectedCallback() {
        this.template.addEventListener('addcontacts', this.handleAddContacts.bind(this));
    }
}

























//     @track applications = [];
//     @track error;

//     columns = [
//         { label: 'Profile', fieldName: 'Candidate_Name__c' },
//         { label: 'Email', fieldName: 'Email__c' },
//         { label: 'Mobile', fieldName: 'Mobile__c' },
//         { label: 'Status', fieldName: 'Status__c' }
//     ];

//     @wire(getJobs)
//     wiredApplications({ error, data }) {
//         if (data) {
//             this.applications = data;
//             this.error = undefined;
//         } else if (error) {
//             this.error = error;
//             this.applications = [];
//         }
//     }

//     get hasApplications() {
//         return this.applications.length > 0;
//     }

//     get showNoApplicationsMessage() {
//         return !this.hasApplications && !this.error;
//     }
// }