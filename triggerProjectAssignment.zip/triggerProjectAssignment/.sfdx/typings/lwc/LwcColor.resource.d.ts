declare module "@salesforce/resourceUrl/LwcColor" {
    var LwcColor: string;
    export default LwcColor;
}