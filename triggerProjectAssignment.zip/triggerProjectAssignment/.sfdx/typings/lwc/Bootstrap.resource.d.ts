declare module "@salesforce/resourceUrl/Bootstrap" {
    var Bootstrap: string;
    export default Bootstrap;
}