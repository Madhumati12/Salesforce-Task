declare module "@salesforce/messageChannel/DashboardUpdate__c" {
    var DashboardUpdate: string;
    export default DashboardUpdate;
}