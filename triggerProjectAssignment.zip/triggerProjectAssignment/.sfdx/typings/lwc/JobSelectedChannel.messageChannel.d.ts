declare module "@salesforce/messageChannel/JobSelectedChannel__c" {
    var JobSelectedChannel: string;
    export default JobSelectedChannel;
}